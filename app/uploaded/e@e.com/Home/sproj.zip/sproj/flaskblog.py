from flask import Flask #import Flask class
app = Flask(__name__)  # set app variable to instance of Flask class
#127.0.0.1 localhost
@app.route("/")  # home route
def hello():
    return "<h1>helloooo<h1>"