import os
from flask import render_template,request,flash,redirect,url_for
from app import app 
#127.0.0.1 localhost
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
posts = [
    {
        'author': 'Corey Schafer',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date_posted': 'April 20, 2018'
    },
    {
        'author': 'Jane Doe',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date_posted': 'April 21, 2018'
    }
]
@app.route("/")  # home/index route
@app.route("/index",  methods=['GET','POST'])
def hello():
    error=''
    try:
        if(request.method == "POST"):
            sub = request.form["submit"]
           
            flash(sub)
           
            if(sub):
                return redirect(url_for('upload'))
            else:
                error = "Invalid try again"
                return render_template('login.html',title='login',error=error)
    except Exception as e:
        flash(e)
        return render_template('login.html',title='login',error=error)
    return render_template('index.html',posts = posts,title="afc")


@app.route("/upload", methods=['GET','POST'])
def upload():
    print(APP_ROOT)
    target = APP_ROOT
    for file in request.files.getlist("file"):
        print(file)
        filename = file.filename
        destn = "/".join([target,filename])
        file.save(destn)
        
    return render_template('upload.html')


@app.route("/about")
def about():
    
    return render_template('about.html')

@app.route("/register", methods=['GET','POST'])
def register():
    print("asdsad")
    #username = request.form['email']
    #print(username)
    return render_template('register.html',title='register')
    


@app.route("/login",methods=['GET','POST'])
def login():
    error=''
    try:
        if(request.method == "POST"):
            attempted_email = request.form["email"]
            attempted_pwd = request.form['password']
            flash(attempted_email)
            flash(attempted_pwd)
            if(attempted_email=="chitta.vssut@gmail.com" and attempted_pwd=="123"):
                return redirect(url_for('hello'))
            else:
                error = "Invalid try again"
                return render_template('login.html',title='login',error=error)
    except Exception as e:
        flash(e)
        return render_template('login.html',title='login',error=error)

    return render_template('login.html',title='login',error=error)
    